\
import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Heart, Music2, ArrowRight, ArrowLeft, Sparkles, Camera, Mail, Stars, Play, Pause } from 'lucide-react';
import './style.css';

const photos = [
  { src: '/photos/couple-1.jpg', label: 'our first little world', wide: true },
  { src: '/photos/couple-2.jpg', label: 'just the two of us', wide: false },
  { src: '/photos/zalffa.jpg', label: 'my favorite girl', wide: false },
  { src: '/photos/andra.jpg', label: 'your favorite boy', wide: false },
];

const startDate = new Date('2026-10-05T19:00:00+07:00');

function durationSince(date) {
  const now = new Date();
  let diff = Math.max(0, now - date);
  const days = Math.floor(diff / 86400000);
  diff %= 86400000;
  const hours = Math.floor(diff / 3600000);
  diff %= 3600000;
  const minutes = Math.floor(diff / 60000);
  diff %= 60000;
  const seconds = Math.floor(diff / 1000);
  return { days, hours, minutes, seconds, future: now < date };
}

function App() {
  const [page, setPage] = useState(0);
  const [time, setTime] = useState(() => durationSince(startDate));
  const [musicOpen, setMusicOpen] = useState(false);

  useEffect(() => {
    const tick = setInterval(() => setTime(durationSince(startDate)), 1000);
    return () => clearInterval(tick);
  }, []);

  const next = () => { setPage(p => (p + 1) % 4); window.scrollTo({ top: 0, behavior: 'smooth' }); };
  const prev = () => { setPage(p => (p + 3) % 4); window.scrollTo({ top: 0, behavior: 'smooth' }); };

  return (
    <div className="app-shell">
      <div className="ambient" aria-hidden="true">
        {Array.from({ length: 18 }, (_, i) => <span key={i} style={{ '--i': i }} className="floating-heart">{i % 3 === 0 ? '♡' : '✧'}</span>)}
      </div>
      <header className="nav">
        <a className="brand" href="#home" onClick={e => { e.preventDefault(); setPage(0); }}>
          <span className="brand-mark"><Heart size={17} fill="currentColor" /></span>
          <span>our little <b>universe</b></span>
        </a>
        <button className="song-button" onClick={() => setMusicOpen(!musicOpen)}>
          <Music2 size={16} /> <span>our song</span> <span className="song-dot" />
        </button>
      </header>

      {musicOpen && <div className="music-panel">
        <div className="music-cover">♫</div>
        <div className="music-copy"><b>We Fell in Love in October</b><span>girl in red</span></div>
        <a className="music-play" href="https://music.youtube.com/search?q=We%20Fell%20in%20Love%20in%20October%20girl%20in%20red" target="_blank" rel="noreferrer"><Play size={16} fill="currentColor" /></a>
      </div>}

      <main>
        {page === 0 && <section className="page hero" key="hero">
          <div className="hero-copy">
            <div className="kicker"><Sparkles size={14} /> OUR STORY BEGINS · 05.10.2026</div>
            <h1>In a world full<br />of people, <em>it's you.</em></h1>
            <p className="intro">Satu cerita kecil tentang dua orang yang menemukan tempat pulang dalam satu sama lain.</p>
            <div className="couple-names"><span>Adzikri Andra Pohan</span><Heart size={18} fill="currentColor" /><span>Zalffa Zascia Indra</span></div>
            <button className="button primary" onClick={next}>masuk ke cerita kita <ArrowRight size={17} /></button>
            <div className="hint"><span className="hint-line" /> A LITTLE LOVE, A LOT OF MEMORIES <span className="hint-line" /></div>
          </div>
          <div className="hero-photos">
            <div className="photo-main"><img src={photos[0].src} alt="Foto Andra dan Zalffa bersama" /><span className="photo-sticker">you + me ♡</span></div>
            <div className="photo-small"><img src={photos[2].src} alt="Potret Zalffa" /></div>
            <div className="heart-seal"><Heart fill="currentColor" size={30} /></div>
            <span className="orbit orbit-one">♡</span><span className="orbit orbit-two">✧</span>
          </div>
        </section>}

        {page === 1 && <section className="page chapter" key="timer">
          <div className="chapter-head"><div className="kicker"><Stars size={14} /> CHAPTER 01 · THE BEGINNING</div><h2>Every love story<br /><em>has its moment.</em></h2><p>Dan momen kita dimulai pada satu malam di bulan Oktober.</p></div>
          <div className="timer-card">
            <div className="timer-top"><span className="live-dot" /> {time.future ? 'COUNTING DOWN TO OUR DAY' : 'TIME SINCE WE BECAME US'}</div>
            <div className="timer-grid">
              {[['days', 'days'], ['hours', 'hours'], ['minutes', 'minutes'], ['seconds', 'seconds']].map(([key, label]) =>
                <div className="time-unit" key={key}><strong>{String(time[key]).padStart(2, '0')}</strong><span>{label}</span></div>
              )}
            </div>
            <div className="date-line"><span>♡</span> 05 OCTOBER 2026 <i>·</i> 7:00 PM WIB <span>♡</span></div>
          </div>
          <div className="note-card"><div className="note-icon"><Heart size={20} fill="currentColor" /></div><div><h3>Not just a date.</h3><p>Ini awal dari banyak hal sederhana yang semoga selalu terasa istimewa: cerita sebelum tidur, tawa kecil, saling mendukung, dan memilih untuk tetap bersama.</p></div></div>
          <div className="actions"><button className="button ghost" onClick={prev}><ArrowLeft size={16} /> kembali</button><button className="button primary" onClick={next}>momen kita <ArrowRight size={17} /></button></div>
        </section>}

        {page === 2 && <section className="page chapter gallery-page" key="gallery">
          <div className="chapter-head"><div className="kicker"><Camera size={14} /> CHAPTER 02 · LITTLE MEMORIES</div><h2>Collected moments,<br /><em>kept forever.</em></h2><p>Hal-hal kecil, wajah favorit, dan kenangan yang selalu ingin disimpan.</p></div>
          <div className="gallery-grid">{photos.map((photo, i) => <figure className={`gallery-photo ${photo.wide ? 'wide' : ''}`} key={photo.src}>
            <img src={photo.src} alt={photo.label} loading="lazy" />
            <figcaption><span>{photo.label}</span><Heart size={15} fill="currentColor" /></figcaption>
          </figure>)}</div>
          <div className="actions"><button className="button ghost" onClick={prev}><ArrowLeft size={16} /> kembali</button><button className="button primary" onClick={next}>sebuah surat <ArrowRight size={17} /></button></div>
        </section>}

        {page === 3 && <section className="page chapter letter-page" key="letter">
          <div className="chapter-head"><div className="kicker"><Mail size={14} /> CHAPTER 03 · JUST FOR YOU</div><h2>To my favorite<br /><em>person.</em></h2></div>
          <article className="letter">
            <div className="letter-top"><span>FOR ZALFFA, WITH LOVE</span><Heart size={19} fill="currentColor" /></div>
            <p className="dear">Untuk Zalffa Zascia Indra,</p>
            <p>Aku nggak tahu semua hal yang akan kita temui ke depannya. Tapi aku tahu, aku ingin menikmati prosesnya sama kamu. Dari hari yang penuh tawa sampai hari yang butuh lebih banyak sabar.</p>
            <p>Terima kasih sudah menjadi bagian dari cerita ini. Semoga kita selalu punya kejujuran untuk bicara, hati yang mau memahami, dan usaha untuk saling menjaga. Kita nggak harus sempurna, kita cuma perlu terus belajar jadi lebih baik bersama.</p>
            <p>Ini baru halaman pertama. Masih banyak cerita yang ingin aku tulis bareng kamu. <span className="pink">♡</span></p>
            <div className="signature">with love, <b>Andra</b></div>
            <div className="letter-stamp">A <Heart size={14} fill="currentColor" /> Z</div>
          </article>
          <div className="actions"><button className="button ghost" onClick={prev}><ArrowLeft size={16} /> lihat lagi</button><button className="button primary" onClick={() => { setPage(0); window.scrollTo({ top: 0, behavior: 'smooth' }); }}>our story, again <Heart size={16} fill="currentColor" /></button></div>
        </section>}
      </main>
      <footer><span>MADE WITH <Heart size={12} fill="currentColor" /> FOR ANDRA & ZALFFA</span><span className="footer-date">05 · 10 · 2026</span></footer>
      <div className="page-progress">{[0,1,2,3].map(n => <button key={n} aria-label={`Halaman ${n+1}`} className={page === n ? 'active' : ''} onClick={() => { setPage(n); window.scrollTo({ top: 0, behavior: 'smooth' }); }} />)}</div>
    </div>
  );
}

createRoot(document.getElementById('root')).render(<React.StrictMode><App /></React.StrictMode>);
