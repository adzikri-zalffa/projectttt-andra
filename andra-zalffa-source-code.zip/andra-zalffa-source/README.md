# Andra ♡ Zalffa — Our Little Universe

Website romantis React + Vite, dengan navigasi per halaman, timer jadian, galeri foto yang menggunakan empat foto yang disediakan, dan tombol menuju lagu.

## Menjalankan di komputer

1. Pasang Node.js versi LTS.
2. Ekstrak ZIP ini.
3. Buka terminal pada folder proyek.
4. Jalankan `npm install`.
5. Jalankan `npm run dev`.
6. Buka alamat lokal yang ditampilkan oleh Vite.

Untuk build produksi:
- `npm run build`
- Hasil build tersedia di folder `dist/`.

## Tanggal jadian

Timer memakai `2026-10-05 19:00 WIB` (UTC+7). Sebelum waktu tersebut, timer menghitung mundur; setelahnya, timer menghitung waktu yang telah berlalu.

## Foto

Foto berada di `public/photos/`. Ganti file foto dengan foto lain jika diperlukan, gunakan nama file yang sama, lalu build ulang.

## Musik

Tombol musik membuka pencarian lagu “We Fell in Love in October” oleh girl in red di YouTube Music. Website tidak menyertakan file lagu, agar tidak mendistribusikan audio berhak cipta.
